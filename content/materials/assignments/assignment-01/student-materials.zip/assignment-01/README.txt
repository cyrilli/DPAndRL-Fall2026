Assignment 1: Dynamic programming

Read assignment_en.pdf for the model, questions, hints, and course-note links.
Complete Problems 1 to 4 (100 points).
Released: November 17, 2026.
Deadline: December 1, 2026, 09:50, before class (China Standard Time, UTC+8).
Submit one PDF with numbered answers through 网络学堂 (Web Learning): https://learn.tsinghua.edu.cn/.

The Lean appendix is optional and ungraded. It requires no submission.

Read the appendix before using lean-starter.zip. The starter contains unfinished
proofs. The completion check is expected to fail until you complete them.
